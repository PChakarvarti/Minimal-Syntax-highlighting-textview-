package com.mycompany.syntax_highlighter;


import android.graphics.Color;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.widget.TextView;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SyntaxHighlightTextView
{

	public static void highlight(TextView textView, String code)
	{
		SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(code);

		// Highlight keywords in blue
		String keywordsRegex = "\\b(public|private|static|final)\\b";
		highlightText(spannableStringBuilder, keywordsRegex, Color.BLUE);

		// Highlight comments in green
		String commentsRegex = "//.*|(\"(?:\\\\[^\"]|\\\\\"|.)*?\")|(?s)/\\*.*?\\*/";
		highlightText(spannableStringBuilder, commentsRegex, Color.GREEN);

		textView.setText(spannableStringBuilder);
	}

	private static void highlightText(SpannableStringBuilder spannableStringBuilder, String regex, int color)
	{
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(spannableStringBuilder);

		while (matcher.find())
		{
			spannableStringBuilder.setSpan(new ForegroundColorSpan(color), matcher.start(), matcher.end(), 0);
		}
	}
}

